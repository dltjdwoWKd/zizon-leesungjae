var searchData=
[
  ['error_20codes_0',['Error codes',['../group__errors.html',1,'']]],
  ['error_20reference_1',['Initialization, version and error reference',['../group__init.html',1,'']]]
];
