#include <GLFW/glfw3.h>
#include <math.h>
#include <stdio.h>

#define PI 3.14159265f
#define CIRCLE_SEGMENTS 100

void draw_filled_ellipse(float cx, float cy, float rx, float ry, float r, float g, float b) {
    glBegin(GL_TRIANGLE_FAN);
    glColor3f(r, g, b);
    glVertex2f(cx, cy);
    for (int i = 0; i <= CIRCLE_SEGMENTS; ++i) {
        float angle = 2.0f * PI * i / CIRCLE_SEGMENTS;
        float x = cx + rx * cosf(angle);
        float y = cy + ry * sinf(angle);
        glVertex2f(x, y);
    }
    glEnd();
}

void draw_ellipse_outline(float cx, float cy, float rx, float ry, float r, float g, float b) {
    glBegin(GL_LINE_LOOP);
    glColor3f(r, g, b);
    for (int i = 0; i < CIRCLE_SEGMENTS; ++i) {
        float angle = 2.0f * PI * i / CIRCLE_SEGMENTS;
        float x = cx + rx * cosf(angle);
        float y = cy + ry * sinf(angle);
        glVertex2f(x, y);
    }
    glEnd();
}

void draw_whiskers() {
    glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_LINES);

    // 왼쪽 수염 (X +5, Y -3)
    glVertex2f(365, 282); glVertex2f(335, 287);
    glVertex2f(365, 272); glVertex2f(335, 272);
    glVertex2f(365, 262); glVertex2f(335, 257);

    // 오른쪽 수염 (X -5, Y -3)
    glVertex2f(435, 282); glVertex2f(465, 287);
    glVertex2f(435, 272); glVertex2f(465, 272);
    glVertex2f(435, 262); glVertex2f(465, 257);

    glEnd();
}

int main(void) {
    if (!glfwInit()) {
        fprintf(stderr, "GLFW 초기화 실패\n");
        return -1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);

    GLFWwindow* window = glfwCreateWindow(800, 600, "해달 얼굴", NULL, NULL);
    if (!window) {
        fprintf(stderr, "윈도우 생성 실패\n");
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 0, 600, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    while (!glfwWindowShouldClose(window)) {
        glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        // 얼굴
        draw_filled_ellipse(400.0f, 300.0f, 100.0f, 90.0f, 0.0f, 0.45f, 0.85f);
        draw_ellipse_outline(400.0f, 300.0f, 100.0f, 90.0f, 0.0f, 0.0f, 0.0f);

        // 눈
        draw_filled_ellipse(320.0f, 330.0f, 8.0f, 8.0f, 0.0f, 0.0f, 0.0f);
        draw_filled_ellipse(480.0f, 330.0f, 8.0f, 8.0f, 0.0f, 0.0f, 0.0f);

        // 수염용 흰색 볼
        draw_filled_ellipse(382.0f, 265.0f, 20.0f, 20.0f, 1.0f, 1.0f, 1.0f); // 왼쪽 볼
        draw_filled_ellipse(418.0f, 265.0f, 20.0f, 20.0f, 1.0f, 1.0f, 1.0f); // 오른쪽 볼

        // 콧수염
        draw_whiskers();

        // 중앙 코 (흰색 원 위에 그려짐)
        draw_filled_ellipse(400.0f, 282.0f, 15.0f, 12.0f, 0.0f, 0.0f, 0.0f);

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
